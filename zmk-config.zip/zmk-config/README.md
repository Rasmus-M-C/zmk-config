# Corne — Wired Split ZMK Config (Pro Micro nRF52840, nice!nano v2-pinout)

This is a `zmk-config` repo for a Corne split keyboard using two Pro Micro
form-factor nRF52840 controllers (pin-compatible with nice!nano v2), where
**the two halves talk to each other over a wired UART link** instead of BLE.

## Why this looks different from a normal Corne config

By default, ZMK Corne configs use Bluetooth between the two halves. This repo
turns that off and enables ZMK's **full-duplex wired UART split** transport
instead — the ZMK docs currently mark this as an early-adopter / experimental
feature, but it's stable enough for daily use, just less battle-tested than
BLE split.

- `config/corne.conf` — sets `CONFIG_ZMK_SPLIT_BLE=n` and `CONFIG_ZMK_SPLIT_WIRED=y`
- `config/corne.keymap` — adds the required `wired_split` devicetree node
  pointing at `&pro_micro_serial` (the UART already broken out on the Pro
  Micro footprint's RXI/TXO pins)

## Wiring

Connect between the two halves:

- Left **TXO** → Right **RXI**
- Left **RXI** → Right **TXO**
- Left **GND** → Right **GND**

A 4-pole TRRS/TRS cable is fine (use 3 of the 4 conductors; the 4th can carry
shared VCC if you want one half unpowered, or be left unused if both halves
have their own power).

⚠️ **Never insert or remove the cable while either half is powered** (USB or
battery) — this can permanently damage the controllers.

## If you're migrating from a BLE-split build with "no keypresses"

If your controllers were previously flashed with a standard (BLE) split
config, that alone explains zero keypresses on a wired build: the two halves
have no way to exchange key events — the central half is listening for a BLE
peripheral that will never show up, and the peripheral is advertising over
BLE into the void. **Both halves need to be reflashed** with firmware built
from this config before wired split will do anything.

Steps to confirm it's working after reflashing:

1. Flash **corne_left** firmware to the half you want as central (the one
   you plug into your computer), and **corne_right** to the other half.
2. Power both halves and connect the TRRS cable *before* powering on, not
   after.
3. Pair the central half over Bluetooth (or plug in via USB) to your
   computer as usual — this Bluetooth step is unaffected by the split
   transport change.
4. Press a key on the peripheral half. If still nothing registers, temporarily
   uncomment `CONFIG_ZMK_USB_LOGGING=y` and `CONFIG_LOG=y` in `corne.conf`,
   reflash, and watch USB serial output — you should see kscan/position
   events being reported.

## Building

This repo is set up for GitHub Actions (`.github/workflows/build.yml` +
`build.yaml`). Push it to a new GitHub repo and Actions will build
`corne_left`, `corne_right`, and a `settings_reset` firmware (handy for
clearing BLE bonds on the central half) as downloadable `.uf2` files.

To build locally instead, see ZMK's
[toolchain setup](https://zmk.dev/docs/development/local-toolchain/setup) and
[build instructions](https://zmk.dev/docs/development/local-toolchain/build-flash).
Example:

```sh
west build -d build/left  -p -b nice_nano_v2 -- -DSHIELD=corne_left  -DZMK_CONFIG="$(pwd)/config"
west build -d build/right -p -b nice_nano_v2 -- -DSHIELD=corne_right -DZMK_CONFIG="$(pwd)/config"
```

## Files

```
zmk-config/
├── build.yaml                    # GitHub Actions build matrix
├── .github/workflows/build.yml   # GitHub Actions workflow
└── config/
    ├── west.yml                  # West manifest, pins ZMK's main branch
    ├── corne.conf                # Kconfig: wired split, disables BLE split
    └── corne.keymap              # Keymap + wired_split devicetree node
```
